# Figure Files README

## Purpose

This folder contains separate figure graphics for the AJPT submission package.

## Files

| File | Manuscript Figure | Caption Location |
|---|---|---|
| `Figure_1_Retrieval_Environment_Validity.svg` | Figure 1. Retrieval-Environment Validity Framework | `AJPT_Main_Manuscript.docx`, Figure Captions section |
| `Figure_2_Methodological_Demonstration_Pipeline.svg` | Figure 2. Methodological Demonstration Pipeline | `AJPT_Main_Manuscript.docx`, Figure Captions section |

## Submission Note

The files are provided as scalable vector graphics. If the final submission system requires another format, such as TIFF, EPS, PNG, or PDF, convert these source SVG files to the required format before upload.

## Boundary Note

The figures visualize the methodological framework and demonstration pipeline. They do not report empirical performance estimates or imply that any retrieval method is generally superior.
